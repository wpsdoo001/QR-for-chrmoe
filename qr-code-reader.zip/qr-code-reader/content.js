/*
 * content.js —— 页面内结果弹窗（隔离世界，独立于页面自身 JS）
 * 同时承担“页内取图”兜底：blob: 地址、需要页面内凭证的图片由这里转 dataURL 交给后台解码。
 */
(function () {
  'use strict';
  if (window.__QRS_DIALOG_INSTALLED__) return;
  window.__QRS_DIALOG_INSTALLED__ = true;

  const ROOT_ID = 'qrs-dialog-root';
  const MAX_GRAB_DIM = 1600;
  const CSS = `
.qrs-backdrop{position:fixed;inset:0;background:rgba(15,18,25,.5);backdrop-filter:blur(2px);z-index:2147483646;display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;line-height:1.5;}
.qrs-panel{width:min(560px,92vw);max-height:80vh;background:#fff;color:#1a1d23;border-radius:14px;box-shadow:0 18px 48px rgba(0,0,0,.28);display:flex;flex-direction:column;overflow:hidden;animation:qrs-in .16s ease-out;}
/* 只做位移动画，不用 opacity：标签页在后台或动画被暂停时弹窗也不会变成“看不见” */
@keyframes qrs-in{from{transform:translateY(8px) scale(.985);}to{transform:none;}}
.qrs-head{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 12px;border-bottom:1px solid #eceef2;}
.qrs-title{font-size:15px;font-weight:600;color:#1a1d23;margin:0;}
.qrs-close{all:unset;cursor:pointer;width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;color:#8a8f98;line-height:1;}
.qrs-close:hover{background:#f1f2f5;color:#1a1d23;}
.qrs-body{padding:16px 18px;overflow:auto;}
.qrs-loading{display:flex;align-items:center;gap:10px;color:#5f6570;font-size:14px;padding:18px 2px;}
.qrs-spinner{width:16px;height:16px;border-radius:50%;border:2px solid #d8dbe2;border-top-color:#3b6ef5;animation:qrs-spin .8s linear infinite;}
@keyframes qrs-spin{to{transform:rotate(360deg);}}
.qrs-badge{display:inline-block;font-size:12px;padding:2px 8px;border-radius:999px;background:#eef3ff;color:#2f5bd3;margin-bottom:10px;}
.qrs-text{margin:0;white-space:pre-wrap;word-break:break-word;font-size:14px;color:#1a1d23;background:#f6f7f9;border:1px solid #eceef2;border-radius:10px;padding:12px;max-height:38vh;overflow:auto;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;user-select:text;}
.qrs-meta{margin-top:10px;font-size:12px;color:#8a8f98;word-break:break-all;}
.qrs-err{font-size:14px;color:#c0392b;padding:8px 0 4px;}
.qrs-tip{margin-top:8px;font-size:13px;color:#5f6570;line-height:1.7;}
.qrs-foot{display:flex;justify-content:flex-end;gap:10px;padding:12px 18px 16px;border-top:1px solid #eceef2;background:#fff;}
.qrs-btn{all:unset;cursor:pointer;font-size:13px;padding:8px 16px;border-radius:8px;border:1px solid #dee1e7;color:#3c4148;background:#fff;transition:background .12s,border-color .12s;text-align:center;}
.qrs-btn:hover{background:#f3f4f7;}
.qrs-btn.qrs-primary{background:#3b6ef5;border-color:#3b6ef5;color:#fff;font-weight:500;}
.qrs-btn.qrs-primary:hover{background:#2f5ed8;border-color:#2f5ed8;}
.qrs-btn[disabled]{opacity:.55;cursor:not-allowed;}
@media (prefers-color-scheme:dark){
.qrs-panel{background:#1f2229;color:#e8eaee;}
.qrs-head,.qrs-foot{border-color:#2c3038;background:#1f2229;}
.qrs-title{color:#e8eaee;}
.qrs-close{color:#9aa1ac;}
.qrs-close:hover{background:#2c3038;color:#fff;}
.qrs-text{background:#171a20;border-color:#2c3038;color:#e8eaee;}
.qrs-meta,.qrs-loading,.qrs-tip{color:#9aa1ac;}
.qrs-badge{background:#26324f;color:#a9c0ff;}
.qrs-err{color:#ff8b7c;}
.qrs-btn{background:#262a31;border-color:#343943;color:#e8eaee;}
.qrs-btn:hover{background:#30353d;}
.qrs-btn.qrs-primary{background:#3b6ef5;border-color:#3b6ef5;color:#fff;}
}
`;

  let root = null;
  let currentNode = { text: '', url: '' };

  /* ---------- 消息入口 ---------- */
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === 'qr:loading') {
      showLoading(msg.srcUrl);
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'qr:result') {
      showResult(msg.result);
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'qr:grab') {
      grabImage(msg.url).then(sendResponse);
      return true; // 异步响应
    }
  });

  /* ---------- 弹窗渲染 ---------- */
  function ensureRoot() {
    if (root && root.isConnected) return root;
    root = document.getElementById(ROOT_ID);
    if (!root) {
      root = document.createElement('div');
      root.id = ROOT_ID;
      const style = document.createElement('style');
      style.textContent = CSS;
      root.appendChild(style);
    }
    (document.body || document.documentElement).appendChild(root);
    return root;
  }

  function teardown() {
    if (root) {
      root.remove();
      root = null;
    }
    document.removeEventListener('keydown', onKeydown, true);
  }

  function onKeydown(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      teardown();
    }
  }

  function baseShell(title) {
    const r = ensureRoot();
    r.innerHTML = '';
    const style = document.createElement('style');
    style.textContent = CSS;
    r.appendChild(style);

    const backdrop = el('div', 'qrs-backdrop');
    const panel = el('div', 'qrs-panel');
    const head = el('div', 'qrs-head');
    const h = el('h3', 'qrs-title');
    h.textContent = title;
    const close = el('button', 'qrs-close');
    close.type = 'button';
    close.title = '关闭';
    close.textContent = '✕';
    close.addEventListener('click', teardown);
    head.append(h, close);

    const body = el('div', 'qrs-body');
    const foot = el('div', 'qrs-foot');
    panel.append(head, body, foot);
    backdrop.appendChild(panel);
    backdrop.addEventListener('mousedown', (e) => {
      if (e.target === backdrop) teardown();
    });
    r.appendChild(backdrop);
    document.addEventListener('keydown', onKeydown, true);
    return { body, foot, panel };
  }

  function showLoading(srcUrl) {
    const { body, foot } = baseShell('二维码识别');
    const wrap = el('div', 'qrs-loading');
    wrap.append(el('div', 'qrs-spinner'), textNode('正在识别图片中的二维码…'));
    body.appendChild(wrap);
    foot.remove();
    if (srcUrl) {
      const meta = el('div', 'qrs-meta');
      meta.textContent = srcUrl.startsWith('data:') ? '图片来源：内嵌数据（data URL）' : '图片来源：' + truncate(srcUrl, 90);
      body.appendChild(meta);
    }
  }

  function showResult(result) {
    result = result || {};
    if (!result.ok) {
      const { body, foot } = baseShell('二维码识别');
      const err = el('div', 'qrs-err');
      err.textContent = result.reason || '识别失败';
      const tip = el('div', 'qrs-tip');
      tip.textContent = '建议：右键一张更清晰、二维码区域更大的图片；带反光或过度压缩的图片可能无法识别。';
      body.append(err, tip);
      const closeBtn = el('button', 'qrs-btn qrs-primary');
      closeBtn.type = 'button';
      closeBtn.textContent = '知道了';
      closeBtn.addEventListener('click', teardown);
      foot.appendChild(closeBtn);
      return;
    }

    const content = String(result.text || '').trim();
    currentNode = { text: content, url: toOpenableUrl(content) };
    const { body, foot } = baseShell('二维码识别结果');

    const badge = el('div', 'qrs-badge');
    const kind = detectKind(content);
    badge.textContent = kind;
    body.appendChild(badge);

    const pre = el('pre', 'qrs-text');
    pre.textContent = content;
    body.appendChild(pre);

    const meta = el('div', 'qrs-meta');
    const parts = [];
    if (result.width && result.height) parts.push(`图片尺寸 ${result.width}×${result.height}`);
    parts.push(`内容长度 ${content.length} 字符`);
    meta.textContent = parts.join(' · ');
    body.appendChild(meta);

    // 复制
    const copyBtn = el('button', 'qrs-btn');
    copyBtn.type = 'button';
    copyBtn.textContent = '复制内容';
    copyBtn.addEventListener('click', async () => {
      const ok = await copyText(content);
      copyBtn.textContent = ok ? '已复制' : '复制失败';
      setTimeout(() => (copyBtn.textContent = '复制内容'), 1500);
    });

    // 打开链接
    if (currentNode.url) {
      const openBtn = el('button', 'qrs-btn');
      openBtn.type = 'button';
      openBtn.textContent = '打开链接';
      openBtn.addEventListener('click', () => {
        window.open(currentNode.url, '_blank', 'noopener');
      });
      foot.appendChild(openBtn);
    }

    const closeBtn = el('button', 'qrs-btn qrs-primary');
    closeBtn.type = 'button';
    closeBtn.textContent = '关闭';
    closeBtn.addEventListener('click', teardown);

    foot.append(copyBtn, closeBtn);
  }

  /* ---------- 页内取图（blob: / 需要页面凭证的图片） ---------- */
  async function grabImage(url) {
    try {
      let img = Array.from(document.images).find((i) => i.currentSrc === url || i.src === url);
      if (!img) img = await loadImage(url);
      if (!img) return { ok: false, reason: '页面上没有找到这张图片' };

      const w = img.naturalWidth || img.width;
      const h = img.naturalHeight || img.height;
      if (!w || !h) return { ok: false, reason: '图片尚未加载完成，请稍后重试' };

      const scale = Math.min(1, MAX_GRAB_DIM / Math.max(w, h));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(w * scale));
      canvas.height = Math.max(1, Math.round(h * scale));
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      return { ok: true, dataUrl };
    } catch (e) {
      return { ok: false, reason: '图片受跨域保护，无法读取像素（可在浏览器中打开原图后另存再识别）' };
    }
  }

  function loadImage(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = url;
      if (img.complete && img.naturalWidth) resolve(img);
    });
  }

  /* ---------- 小工具 ---------- */
  function el(tag, cls) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    return node;
  }

  function textNode(t) {
    return document.createTextNode(t);
  }

  function truncate(s, n) {
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }

  function detectKind(text) {
    if (/^WIFI:/i.test(text)) return 'Wi-Fi 配置';
    if (/^BEGIN:VCARD/i.test(text)) return '名片';
    if (/^mailto:/i.test(text)) return '邮件地址';
    if (/^tel:/i.test(text)) return '电话号码';
    if (/^smsto:|^sms:/i.test(text)) return '短信';
    if (/^geo:/i.test(text)) return '地理位置';
    if (/^https?:\/\//i.test(text)) return '网址链接';
    if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(text)) return '邮箱地址';
    return '文本内容';
  }

  // 纯链接直接打开；以链接开头（后面还跟了别的文字）时取第一个链接
  function toOpenableUrl(text) {
    const m = text.match(/^https?:\/\/[^\s"'<>]+/i);
    return m ? m[0] : '';
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      /* 继续用兜底方案 */
    }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', 'readonly');
      ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;padding:0;border:0;';
      document.documentElement.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (e) {
      return false;
    }
  }
})();
