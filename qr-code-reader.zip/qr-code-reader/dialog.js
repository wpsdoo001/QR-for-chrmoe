/* dialog.js —— 受限页面下的结果窗口（从 storage 读取最近一次识别结果） */
(async function () {
  const app = document.getElementById('app');
  const copyBtn = document.getElementById('copy');
  const openBtn = document.getElementById('open');
  const closeBtn = document.getElementById('close');
  let text = '';
  let url = '';

  closeBtn.addEventListener('click', () => window.close());
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') window.close();
  });

  copyBtn.addEventListener('click', async () => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      copyBtn.textContent = '已复制';
    } catch (e) {
      copyBtn.textContent = '复制失败';
    }
    setTimeout(() => (copyBtn.textContent = '复制内容'), 1500);
  });

  openBtn.addEventListener('click', () => {
    if (url) window.open(url, '_blank', 'noopener');
  });

  async function readResult() {
    for (const area of [chrome.storage.session, chrome.storage.local]) {
      try {
        const data = await area.get('qrLastResult');
        if (data && data.qrLastResult) return data.qrLastResult;
      } catch (e) {
        /* 忽略，换下一个存储区 */
      }
    }
    return null;
  }

  const result = await readResult();
  if (!result) {
    app.innerHTML = '<div class="err">没有可显示的结果</div>';
    copyBtn.hidden = true;
    return;
  }

  if (!result.ok) {
    app.innerHTML = '<div class="err"></div><div class="tip"></div>';
    app.querySelector('.err').textContent = result.reason || '识别失败';
    app.querySelector('.tip').textContent = '建议：右键一张更清晰、二维码区域更大的图片。';
    copyBtn.hidden = true;
    return;
  }

  text = String(result.text || '').trim();
  const linkMatch = text.match(/^https?:\/\/[^\s"'<>]+/i);
  url = linkMatch ? linkMatch[0] : '';

  const badge = document.createElement('div');
  badge.className = 'badge';
  badge.textContent = detectKind(text);
  const pre = document.createElement('pre');
  pre.textContent = text;
  const meta = document.createElement('div');
  meta.className = 'meta';
  const parts = [];
  if (result.width && result.height) parts.push(`图片尺寸 ${result.width}×${result.height}`);
  parts.push(`内容长度 ${text.length} 字符`);
  meta.textContent = parts.join(' · ');

  app.append(badge, pre, meta);
  if (url) openBtn.hidden = false;

  function detectKind(t) {
    if (/^WIFI:/i.test(t)) return 'Wi-Fi 配置';
    if (/^BEGIN:VCARD/i.test(t)) return '名片';
    if (/^mailto:/i.test(t)) return '邮件地址';
    if (/^tel:/i.test(t)) return '电话号码';
    if (/^geo:/i.test(t)) return '地理位置';
    if (/^https?:\/\//i.test(t)) return '网址链接';
    return '文本内容';
  }
})();
