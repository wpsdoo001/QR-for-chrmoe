/*
 * qr-scan.js —— 二维码解码核心（纯逻辑，不依赖 DOM）
 * 依赖 jsQR.js 暴露的全局 jsQR 函数。
 * 在 Service Worker 中通过 importScripts 加载；也可在 Node 中直接 require 做单元测试。
 */
(function (global) {
  'use strict';

  // 针对不同尺寸图片生成若干候选绘制尺寸，提高识别成功率
  function scaleCandidates(w, h) {
    const out = [];
    const seen = new Set();
    const maxDim = Math.max(w, h);
    const push = (tw, th) => {
      tw = Math.round(tw);
      th = Math.round(th);
      if (tw < 24 || th < 24) return;
      const key = tw + 'x' + th;
      if (seen.has(key)) return;
      seen.add(key);
      out.push({ w: tw, h: th });
    };

    // 1. 原尺寸（过大时等比压到 1600 以内）
    if (maxDim <= 1600) push(w, h);
    else push((w * 1600) / maxDim, (h * 1600) / maxDim);

    // 2. 统一压到 1200 以内，兼顾速度与精度
    if (maxDim > 1200) push((w * 1200) / maxDim, (h * 1200) / maxDim);

    // 3. 图片偏小时放大，二维码需要足够的像素密度才能定位
    if (maxDim < 640) push(w * 2, h * 2);
    if (maxDim < 320) push(w * 3, h * 3);
    if (maxDim < 160) push(w * 4, h * 4);

    return out;
  }

  // 输入 RGBA 像素数据，返回解码文本；失败返回 null
  function decodeImageData(data, w, h) {
    if (typeof global.jsQR !== 'function') throw new Error('jsQR 未加载');
    if (!data || w < 24 || h < 24) return null;
    let result = null;
    try {
      result = global.jsQR(data, w, h, { inversionAttempts: 'attemptBoth' });
    } catch (e) {
      return null;
    }
    return result && result.data ? result.data : null;
  }

  global.QrScan = { scaleCandidates, decodeImageData };
})(typeof self !== 'undefined' ? self : globalThis);
