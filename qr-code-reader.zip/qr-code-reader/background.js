/*
 * background.js —— 右键菜单 + 二维码解码（Service Worker）
 *
 * 为什么在后台解码：Service Worker 里 fetch 不受页面 CORS 限制，
 * 配合 OffscreenCanvas + createImageBitmap 即可拿到像素数据交给 jsQR。
 */
importScripts('jsQR.js', 'qr-scan.js');

const MENU_ID = 'qr_scan_image';
const MAX_PIXELS = 1600; // 单次解码绘制的最大边长

/* ---------------- 右键菜单 ---------------- */

function createMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: '识别二维码',
      contexts: ['image']
    });
  });
}

chrome.runtime.onInstalled.addListener(createMenu);
chrome.runtime.onStartup.addListener(createMenu);

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID) return;
  handleScan(info, tab).catch((err) => {
    console.error('[二维码识别] 未捕获错误', err);
  });
});

/* ---------------- 主流程 ---------------- */

async function handleScan(info, tab) {
  const srcUrl = info.srcUrl || '';
  const frameId = typeof info.frameId === 'number' ? info.frameId : 0;
  const tabId = tab && typeof tab.id === 'number' ? tab.id : -1;

  // 1) 先把页内弹窗脚本注入当前标签页（也是页面内取图的兜底通道）
  let inPage = false;
  if (tabId >= 0) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId, frameIds: [frameId] },
        files: ['content.js']
      });
      inPage = true;
    } catch (e) {
      inPage = false; // chrome:// 、扩展商店等受限页面
    }
  }

  // 2) 立刻给出“识别中”的反馈
  if (inPage) {
    sendToFrame(tabId, frameId, { type: 'qr:loading', srcUrl }).catch(() => {});
  }

  // 3) 解码
  const result = await scanImage(srcUrl, tabId, frameId, inPage);

  // 4) 展示结果：优先页面内弹窗，失败则用独立小窗口
  if (inPage) {
    const shown = await sendToFrame(tabId, frameId, { type: 'qr:result', result }).catch(() => false);
    if (shown) return;
  }
  await showFallbackWindow(result);
}

/* ---------------- 取图与解码 ---------------- */

async function scanImage(srcUrl, tabId, frameId, inPage) {
  if (!srcUrl) return fail('没有获取到这张图片的地址');

  // blob: 地址只在页面上下文有效，后台无法 fetch，直接走页内取图
  if (!srcUrl.startsWith('blob:')) {
    try {
      const resp = await fetch(srcUrl, { credentials: 'include' });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const blob = await resp.blob();
      if (!blob || blob.size === 0) throw new Error('图片内容为空');
      return await scanBlob(blob, srcUrl);
    } catch (e) {
      // 交给页内脚本兜底（例如图片需要页面内凭证）
    }
  }

  if (inPage && tabId >= 0) {
    try {
      const grabbed = await chrome.tabs.sendMessage(
        tabId,
        { type: 'qr:grab', url: srcUrl },
        { frameId }
      );
      if (grabbed && grabbed.ok && grabbed.dataUrl) {
        const blob = dataUrlToBlob(grabbed.dataUrl);
        return await scanBlob(blob, srcUrl);
      }
      return fail(grabbed && grabbed.reason ? grabbed.reason : '图片读取失败');
    } catch (e) {
      return fail('图片读取失败，该页面可能限制了跨域访问');
    }
  }
  return fail('图片读取失败，该页面可能限制了跨域访问');
}

async function scanBlob(blob, imageUrl) {
  let bitmap;
  try {
    bitmap = await createImageBitmap(blob);
  } catch (e) {
    return fail('这张图片的格式无法解析（支持的格式取决于浏览器）');
  }

  try {
    const w = bitmap.width;
    const h = bitmap.height;
    const base = { imageUrl, width: w, height: h };

    // 第一轮：整体多尺度扫描
    for (const c of QrScan.scaleCandidates(w, h)) {
      const text = drawAndDecode(bitmap, 0, 0, w, h, c.w, c.h);
      if (text) return { ok: true, text, ...base };
    }

    // 第二轮：大图切块扫描（二维码只占画面一角时更容易命中）
    if (Math.max(w, h) >= 700) {
      const tiles = buildTiles(w, h);
      for (const t of tiles) {
        const scaled = Math.max(t.w, t.h) > MAX_PIXELS ? 1200 / Math.max(t.w, t.h) : 1;
        const text = drawAndDecode(
          bitmap, t.x, t.y, t.w, t.h,
          Math.round(t.w * scaled), Math.round(t.h * scaled)
        );
        if (text) return { ok: true, text, ...base };
      }
    }

    return fail('未在这张图片中找到二维码');
  } finally {
    if (bitmap && bitmap.close) bitmap.close();
  }
}

// 2x2 切块，块与块之间留 12% 重叠，避免二维码正好被切开
function buildTiles(w, h) {
  const ow = Math.floor(w / 2);
  const oh = Math.floor(h / 2);
  const rx = Math.floor(w * 0.12);
  const ry = Math.floor(h * 0.12);
  const tiles = [];
  for (let i = 0; i < 2; i++) {
    for (let j = 0; j < 2; j++) {
      const x = Math.max(0, i * ow - rx);
      const y = Math.max(0, j * oh - ry);
      const tw = Math.min(w - x, ow + rx * 2);
      const th = Math.min(h - y, oh + ry * 2);
      tiles.push({ x, y, w: tw, h: th });
    }
  }
  return tiles;
}

function drawAndDecode(bitmap, sx, sy, sw, sh, tw, th) {
  let canvas;
  try {
    canvas = new OffscreenCanvas(tw, th);
  } catch (e) {
    return null;
  }
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, tw, th);
  let imageData;
  try {
    imageData = ctx.getImageData(0, 0, tw, th);
  } catch (e) {
    return null;
  }
  return QrScan.decodeImageData(imageData.data, tw, th);
}

/* ---------------- 工具函数 ---------------- */

function fail(reason) {
  return { ok: false, reason };
}

function dataUrlToBlob(dataUrl) {
  const comma = dataUrl.indexOf(',');
  const header = dataUrl.slice(0, comma);
  const body = dataUrl.slice(comma + 1);
  const mime = (header.match(/data:([^;]+)/) || [, 'image/png'])[1];
  if (/;base64/i.test(header)) {
    const bin = atob(body);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }
  return new Blob([decodeURIComponent(body)], { type: mime });
}

async function sendToFrame(tabId, frameId, message) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, message, { frameId });
    return res !== undefined ? res : true;
  } catch (e) {
    return false;
  }
}

async function showFallbackWindow(result) {
  try {
    await chrome.storage.session.set({ qrLastResult: result });
  } catch (e) {
    await chrome.storage.local.set({ qrLastResult: result });
  }
  chrome.windows.create({
    url: chrome.runtime.getURL('dialog.html'),
    type: 'popup',
    width: 540,
    height: 480
  });
}
